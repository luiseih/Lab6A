package w06.firstWindowRewriteSyntax;

public class FirstWindowDriver{

    public static void main(String[] args){

        FirstWindow fw = new FirstWindow();
        fw.setVisible(true);

        //FirstWindowInner fwInner = new FirstWindowInner();
        //fwInner.setVisible(true);

    }
}
