package w06.firstWindowRewriteSyntax;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EndButtonClickListener implements ActionListener {

    public void actionPerformed(ActionEvent e){

    System.exit(0); //exit normally
    }
}

