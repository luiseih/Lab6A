package w06.layoutManager;


public class BorderLayoutManagerDriver {

    public static void main(String[] args) {
        BorderLayoutManager blm = new BorderLayoutManager();

        blm.setVisible(true);
    }

}
