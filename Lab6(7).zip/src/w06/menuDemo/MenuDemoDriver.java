package w06.menuDemo;

public class MenuDemoDriver {

  public static void main(String[] args) {
    MenuDemo gui = new MenuDemo();
    gui.setVisible(true);
  }
}
