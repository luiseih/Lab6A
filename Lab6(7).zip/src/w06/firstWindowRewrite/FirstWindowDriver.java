package w06.firstWindowRewrite;

public class FirstWindowDriver{

    public static void main(String[] args){

        FirstWindow fw = new FirstWindow();
        fw.setVisible(true);
    }
}
